function multiply(a,b=3){
    return (a*b*1);
}

function Dice(rollDice = 6){
    return (Math.floor(Math.random()*rollDice));
}
Dice();