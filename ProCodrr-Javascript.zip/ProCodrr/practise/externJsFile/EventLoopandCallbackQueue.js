console.log('Hii-1');

function hello(){
    console.log('Hello World');
}

for (let i = 1; i <= 5; i++){
    console.log(i);
}

console.log('Hi-2')

// console.log("Message printing Using loop");

// for(let i = 1; i <= 100; i++){
//     setTimeout(() => {
//         console.log("Hi - " + i );
//       }, i * 1000);
// }

// console.log('Transaction Has Begun');

// function hello(){
//   console.log('Hello World');
// }

//   for(let i = 1; i <= 10; i++) {
//     setTimeout(() => {
//       console.log('$'+ i +' Million Has Been Credited In Your Account Number ending with xxxx8194');
//     }, i*1000);
//   }

// setTimeout('console.log("Transaction Completed")',11000);