let Mouse =  'Mouse';
let Mouse2 = Mouse;
console.log(Mouse2);

const rajaG = {
    username : "remoteRani",
    age : '22',
    title : "Hot and single"
}

const rajaG1 = { 
    username: "remoteRani", 
    age: '22', 
    title: "Hot and single" 
}

console.log(rajaG1 === rajaG);