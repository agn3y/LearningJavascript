const name = "Agney"

console.log(navigator.userAgent);   // Displays browser details
console.log(navigator.language);    // Displays the browser's language
console.log(location.href);         // Logs the current page URL
console.log(screen.width);          // Logs the screen width
console.log(screen.height);         // Logs the screen height
// // location.reload();               // Reloads the current page
// // history.back();                  // Goes to the previous page
// // history.forward();               // Moves to the next page

// location.href="https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model";

scroll({
    top: 100,
    behavior: "smooth",
  });