const h1 = document.querySelector('.h1')
const container = document.querySelector('.container')


// h1.cloneNode(true)
// container.appendChild(h1) // use in console
// container.appendChild(h1.cloneNode(true))

// for(let i = 0; i < 100 ; i++){
//     container.appendChild(card.cloneNode(i))
// }


