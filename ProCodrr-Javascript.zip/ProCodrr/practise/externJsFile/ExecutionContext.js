debugger

sayHi()

const username = 'Anirudh'
const userAge = 25

function sayHi(a,b) {
    add(7, 9)
    return a+b
}

console.log(sayHi(22,20))

function add(x, y) {
    kuchhBhi()
    return x + y
}

function kuchhBhi() {
    console.log('Kuchh bhi');
}

console.log('Program Ended');

