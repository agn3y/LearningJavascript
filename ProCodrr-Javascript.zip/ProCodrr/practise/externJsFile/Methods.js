const methodExplain = {
    name : 'Method Explanation',
    add : function(a,b){
        return a + b;
    },
    sub : function(a,b){
        return a - b;
    },
    mul : function(a,b){
        return a * b;
    },
}

console.dir(methodExplain.add(2,312222));
console.dir(methodExplain.sub(88,3));
console.dir(methodExplain. mul(222,3));
