// const additionNum = (number1,number2) => number1 + number2 * 2
// console.log(additionNum(4,33))

// lllllllllllll

   for (let i = 1; i <= 1000; i++) {
    setTimeout(() => {
        console.log("Number - " + i);
    }, i * 10);
}

